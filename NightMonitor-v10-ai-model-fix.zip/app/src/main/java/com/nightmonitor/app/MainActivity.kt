package com.nightmonitor.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var aiStatusText: TextView
    private lateinit var confidenceText: TextView
    private lateinit var topLabelText: TextView
    private lateinit var detectionCountText: TextView
    private lateinit var downloadModelBtn: Button
    private lateinit var startStopBtn: Button
    private lateinit var recordBtn: Button
    private lateinit var playBtn: Button
    private lateinit var deleteBtn: Button
    private lateinit var clipStatusText: TextView
    private lateinit var autoPlaySwitch: Switch
    private lateinit var pitchFocusSwitch: Switch
    private lateinit var testModeSwitch: Switch
    private lateinit var sensitivitySeekBar: SeekBar
    private lateinit var logText: TextView
    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private var isRecordingClip = false
    private var isMonitoring = false
    private val logLines = mutableListOf<String>()
    private val clipFile: File get() = File(filesDir, "voice_clip.m4a")

    private val eventReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val type = intent?.getStringExtra("type") ?: return
            val timeMs = intent.getLongExtra("time", System.currentTimeMillis())
            val aiReady = intent.getBooleanExtra("aiReady", false)
            when (type) {
                "live" -> {
                    val confidence = intent.getFloatExtra("confidence", 0f)
                    val label = intent.getStringExtra("label") ?: "Unknown"
                    val top = intent.getStringExtra("topLabel") ?: label
                    confidenceText.text = "Cat confidence: ${(confidence * 100).toInt()}%"
                    topLabelText.text = "Best match: $label  •  overall: $top"
                    aiStatusText.text = if (aiReady) "AI active • live analysis" else "AI model missing"
                    statusText.text = if (prefs.getBoolean("testMode", false)) "Test mode • analysing" else "Listening"
                }
                "status" -> {
                    statusText.text = intent.getStringExtra("status") ?: "Listening"
                    aiStatusText.text = if (aiReady) "AI model ready" else "AI model not installed"
                }
                "played", "heard", "ignored" -> {
                    val confidence = intent.getFloatExtra("confidence", -1f)
                    val label = intent.getStringExtra("label")
                    val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
                    val base = when (type) { "played" -> "Played your clip"; "ignored" -> "Ignored"; else -> "Cat-like sound detected" }
                    val suffix = if (confidence >= 0f) " • ${label ?: "cat"} ${(confidence * 100).toInt()}%" else ""
                    addLogLine(fmt.format(Date(timeMs)) + " — " + base + suffix)
                    if (type != "ignored") detectionCountText.text = "Detections: ${logLines.count { it.contains("Played") || it.contains("detected") }}"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("night_monitor_prefs", Context.MODE_PRIVATE)
        statusText = findViewById(R.id.statusText); aiStatusText = findViewById(R.id.aiStatusText)
        confidenceText = findViewById(R.id.confidenceText); topLabelText = findViewById(R.id.topLabelText)
        detectionCountText = findViewById(R.id.detectionCountText); downloadModelBtn = findViewById(R.id.downloadModelBtn); startStopBtn = findViewById(R.id.startStopBtn)
        recordBtn = findViewById(R.id.recordBtn); playBtn = findViewById(R.id.playBtn); deleteBtn = findViewById(R.id.deleteBtn)
        clipStatusText = findViewById(R.id.clipStatusText); autoPlaySwitch = findViewById(R.id.autoPlaySwitch)
        pitchFocusSwitch = findViewById(R.id.pitchFocusSwitch); testModeSwitch = findViewById(R.id.testModeSwitch)
        sensitivitySeekBar = findViewById(R.id.sensitivitySeekBar); logText = findViewById(R.id.logText)
        sensitivitySeekBar.progress = prefs.getInt("sensitivity", 22)
        autoPlaySwitch.isChecked = prefs.getBoolean("autoPlay", true)
        pitchFocusSwitch.isChecked = prefs.getBoolean("pitchFocus", true)
        testModeSwitch.isChecked = prefs.getBoolean("testMode", false)
        loadHistory(); updateClipUI(); updateModelStatus(); requestPermissionsIfNeeded()
        downloadModelBtn.setOnClickListener { downloadAiModel() }
        if (!ModelDownloader.isModelPresent(this)) {
            aiStatusText.text = "AI model missing • tap Download AI model"
        }
        recordBtn.setOnClickListener { if (isRecordingClip) stopRecordingClip() else startRecordingClip() }
        playBtn.setOnClickListener { playClip() }; deleteBtn.setOnClickListener { deleteClip() }
        startStopBtn.setOnClickListener { if (isMonitoring) stopMonitoring() else startMonitoring() }
        sensitivitySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { prefs.edit().putInt("sensitivity", p).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        autoPlaySwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("autoPlay", c).apply() }
        pitchFocusSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("pitchFocus", c).apply() }
        testModeSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("testMode", c).apply(); statusText.text = if (c) "Test mode ready" else "Off" }
    }
    override fun onStart() { super.onStart(); val f=IntentFilter(MonitorService.EVENT_ACTION); if(Build.VERSION.SDK_INT>=33) registerReceiver(eventReceiver,f,Context.RECEIVER_NOT_EXPORTED) else registerReceiver(eventReceiver,f) }
    override fun onStop() { super.onStop(); try { unregisterReceiver(eventReceiver) } catch(_:Exception){} }
    private fun addLogLine(line:String) { logLines.add(0,line); while(logLines.size>12) logLines.removeAt(logLines.size-1); prefs.edit().putString("history", logLines.joinToString("\n")).apply(); logText.text=logLines.joinToString("\n") }
    private fun loadHistory(){ val raw=prefs.getString("history","") ?: ""; if(raw.isNotBlank()) logLines.addAll(raw.lines().take(12)); logText.text=if(logLines.isEmpty()) "Nothing yet." else logLines.joinToString("\n"); detectionCountText.text="Detections: ${logLines.count { it.contains("Played") || it.contains("detected") }}" }
    private fun updateModelStatus(){
        val ready = ModelDownloader.isModelPresent(this)
        aiStatusText.text = if (ready) "AI model ready" else "AI model missing • tap Download AI model"
        downloadModelBtn.text = if (ready) "AI model ready ✓" else "Download AI model"
        downloadModelBtn.isEnabled = !ready
    }
    private fun downloadAiModel(){
        if (ModelDownloader.isModelPresent(this)) { updateModelStatus(); return }
        downloadModelBtn.isEnabled = false
        downloadModelBtn.text = "Downloading AI model…"
        aiStatusText.text = "Downloading AI model…"
        ModelDownloader.download(this) { ok, message ->
            runOnUiThread {
                aiStatusText.text = message
                downloadModelBtn.text = if (ok) "AI model ready ✓" else "Retry AI model download"
                downloadModelBtn.isEnabled = !ok
                if (!ok) downloadModelBtn.setOnClickListener { downloadAiModel() }
            }
        }
    }
    private fun requestPermissionsIfNeeded(){ val n=mutableListOf<String>(); if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)n.add(Manifest.permission.RECORD_AUDIO); if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)n.add(Manifest.permission.POST_NOTIFICATIONS); if(n.isNotEmpty())ActivityCompat.requestPermissions(this,n.toTypedArray(),100) }
    private fun hasRecordPermission()=ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED
    private fun startRecordingClip(){ if(!hasRecordPermission()){requestPermissionsIfNeeded();return}; val r=MediaRecorder(); try{r.setAudioSource(MediaRecorder.AudioSource.MIC);r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);r.setOutputFile(clipFile.absolutePath);r.prepare();r.start()}catch(e:Exception){Toast.makeText(this,"Couldn't start recording: ${e.message}",Toast.LENGTH_SHORT).show();return};mediaRecorder=r;isRecordingClip=true;recordBtn.text="Stop";clipStatusText.text="Recording… tap Stop when done" }
    private fun stopRecordingClip(){try{mediaRecorder?.stop()}catch(_:Exception){};mediaRecorder?.release();mediaRecorder=null;isRecordingClip=false;recordBtn.text="Record";updateClipUI()}
    private fun playClip(){if(!clipFile.exists())return;mediaPlayer?.release();val p=MediaPlayer();try{p.setDataSource(clipFile.absolutePath);p.setOnPreparedListener{it.start()};p.setOnCompletionListener{it.release()};p.prepareAsync();mediaPlayer=p}catch(e:Exception){Toast.makeText(this,"Couldn't play clip: ${e.message}",Toast.LENGTH_SHORT).show()}}
    private fun deleteClip(){if(clipFile.exists())clipFile.delete();updateClipUI()}
    private fun updateClipUI(){val e=clipFile.exists();clipStatusText.text=if(e)"Clip saved and ready" else "No clip saved yet";playBtn.isEnabled=e;deleteBtn.isEnabled=e}
    private fun startMonitoring(){if(!hasRecordPermission()){requestPermissionsIfNeeded();return};ContextCompat.startForegroundService(this,Intent(this,MonitorService::class.java).apply{action=MonitorService.ACTION_START});isMonitoring=true;startStopBtn.text="Stop monitoring";statusText.text=if(testModeSwitch.isChecked)"Test mode • listening" else "Listening"}
    private fun stopMonitoring(){startService(Intent(this,MonitorService::class.java).apply{action=MonitorService.ACTION_STOP});isMonitoring=false;startStopBtn.text="Start monitoring";statusText.text="Off"}
}
