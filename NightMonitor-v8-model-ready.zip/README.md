# NightMonitor v8 — Model Integration Ready

This version keeps the v7 dashboard/test-mode pipeline and fixes quantized UINT8/INT8 input handling.

## Add the real YAMNet model

The app intentionally does **not** bundle the binary model in this ZIP. Put the official MediaPipe YAMNet float32 model at:

`app/src/main/assets/yamnet.tflite`

Official model endpoint used by the helper scripts:
`https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite`

Run one of:

- Linux/macOS: `./scripts/download_yamnet_model.sh`
- Windows PowerShell: `./scripts/download_yamnet_model.ps1`

Then build/install the app. The dashboard should change from **AI model not installed** to **AI model ready**.

## Audio contract

YAMNet uses 16 kHz mono waveform input. Its reference pipeline uses about 0.96 s analysis patches and needs roughly 0.975 s of waveform for the first output frame. NightMonitor therefore feeds 15,600 samples per inference window. See the TensorFlow YAMNet reference for the exact preprocessing/model parameters.

## Important

A YAMNet score is an audio-event classification score, not a guarantee that a sound came from a specific cat. NightMonitor uses the Cat/Purr/Meow/Hiss/Caterwaul classes plus consecutive-window confirmation and cooldown to reduce false triggers.
