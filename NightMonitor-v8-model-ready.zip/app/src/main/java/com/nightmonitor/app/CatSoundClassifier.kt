package com.nightmonitor.app

import android.content.Context
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Optional on-device YAMNet-compatible classifier.
 * Supports common float32 and quantized TFLite input/output tensors.
 */
class CatSoundClassifier(private val context: Context) : AutoCloseable {
    companion object {
        private const val MODEL = "yamnet.tflite"
        const val SAMPLE_RATE = 16000
        const val INPUT_SAMPLES = 15600
        private val CAT_INDICES = intArrayOf(76, 77, 78, 79, 80)
        private val CAT_LABELS = mapOf(76 to "Cat", 77 to "Purr", 78 to "Meow", 79 to "Hiss", 80 to "Caterwaul")
    }

    data class Result(
        val catConfidence: Float,
        val bestCatLabel: String?,
        val bestCatConfidence: Float,
        val topLabel: String?,
        val topConfidence: Float
    )

    private var interpreter: Interpreter? = null
    private var inputType: DataType? = null
    private var outputType: DataType? = null

    init {
        try {
            val model = context.assets.open(MODEL).use { it.readBytes() }
            val buffer = ByteBuffer.allocateDirect(model.size).order(ByteOrder.nativeOrder())
            buffer.put(model).rewind()
            val t = Interpreter(buffer)
            interpreter = t
            inputType = t.getInputTensor(0).dataType()
            outputType = t.getOutputTensor(0).dataType()
        } catch (_: Exception) {
            interpreter = null
        }
    }

    fun isReady(): Boolean = interpreter != null

    fun classify(samples: ShortArray, count: Int): Result? {
        val t = interpreter ?: return null
        if (count <= 0) return null
        return try {
            val input = t.getInputTensor(0)
            val shape = input.shape()
            val inputElements = shape.fold(1) { a, b -> a * b }
            if (inputElements < INPUT_SAMPLES) return null

            val waveform = FloatArray(inputElements)
            val n = minOf(count, INPUT_SAMPLES)
            for (i in 0 until n) waveform[i] = samples[i] / 32768f

            val inputObject: Any = when (inputType) {
                DataType.FLOAT32 -> if (shape.size == 1) waveform.copyOf(INPUT_SAMPLES) else arrayOf(waveform.copyOf(INPUT_SAMPLES))
                DataType.UINT8, DataType.INT8 -> quantizedInput(waveform, input, shape)
                else -> return null
            }

            val outTensor = t.getOutputTensor(0)
            val outShape = outTensor.shape()
            val classCount = outShape.lastOrNull() ?: return null
            if (classCount < 81) return null
            val frameCount = if (outShape.size <= 1) 1 else outShape.dropLast(1).fold(1) { a, b -> a * b }
            val raw = Array(frameCount) { FloatArray(classCount) }

            val outputObject: Any = if (outShape.size <= 1) raw[0] else raw
            t.run(inputObject, outputObject)

            val scores = FloatArray(classCount)
            for (frame in raw) for (i in 0 until classCount) scores[i] += dequant(frame[i], outTensor)
            if (raw.size > 1) for (i in scores.indices) scores[i] /= raw.size.toFloat()

            var topIndex = 0
            for (i in 1 until classCount) if (scores[i] > scores[topIndex]) topIndex = i
            var bestCat = 0f
            var bestLabel: String? = null
            for (index in CAT_INDICES) {
                if (index < classCount && scores[index] > bestCat) {
                    bestCat = scores[index].coerceIn(0f, 1f)
                    bestLabel = CAT_LABELS[index]
                }
            }
            Result(bestCat, bestLabel, bestCat, CAT_LABELS[topIndex] ?: "Class $topIndex", scores[topIndex].coerceIn(0f, 1f))
        } catch (_: Exception) { null }
    }

    private fun quantizedInput(waveform: FloatArray, tensor: org.tensorflow.lite.Tensor, shape: IntArray): Any {
        val q = tensor.quantizationParams()
        val scale = if (q.scale == 0f) 1f else q.scale
        val zero = q.zeroPoint
        val bytes = ByteArray(INPUT_SAMPLES)
        for (i in 0 until INPUT_SAMPLES) {
            val v = kotlin.math.round(waveform[i] / scale + zero).toInt().coerceIn(-128, 127)
            bytes[i] = v.toByte()
        }
        return if (inputType == DataType.UINT8) {
            val u = ByteArray(INPUT_SAMPLES)
            for (i in bytes.indices) u[i] = (bytes[i].toInt().coerceIn(0, 255)).toByte()
            if (shape.size == 1) u else arrayOf(u)
        } else {
            if (shape.size == 1) bytes else arrayOf(bytes)
        }
    }

    private fun dequant(value: Float, tensor: org.tensorflow.lite.Tensor): Float {
        if (outputType == DataType.FLOAT32) return value
        val q = tensor.quantizationParams()
        return (value - q.zeroPoint) * q.scale
    }

    override fun close() { interpreter?.close(); interpreter = null }
}
