# NightMonitor v13 — Foreground Service Hardening

- Explicitly starts the microphone foreground service with `FOREGROUND_SERVICE_TYPE_MICROPHONE`.
- Keeps v12 Night Schedule, AI model downloader, smart filter, cooldown, Test Mode and activity history.
- This matches Android's current microphone foreground-service requirements for target SDK 34+.
