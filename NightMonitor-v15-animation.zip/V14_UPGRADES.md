# NightMonitor v14

## Battery + Night Dashboard
- Added Battery Saver AI analysis toggle. When enabled, AI inference runs less often to reduce CPU work while retaining the same audio window and detection logic.
- Added live battery percentage display.
- Added persistent total-detection counter and last-detection time.
- Kept Night Schedule, Smart Cooldown, AI model download, Test Mode and v13 microphone foreground-service hardening.
- Uses the explicit microphone foreground-service type when starting the service, matching current Android requirements.
