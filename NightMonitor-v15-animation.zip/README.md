# NightMonitor — AI model fix

This version fixes the **“AI model not installed”** problem by allowing the app to download and cache the real YAMNet TFLite model inside its private app storage.

Open NightMonitor and tap **Download AI model**. After a successful download the app shows **AI model ready ✓**. Then start monitoring.

The model is downloaded over HTTPS from the same MediaPipe model endpoint used by the included helper script. The model is not bundled in this ZIP, so the APK remains small.


## v14
Battery Saver AI analysis + battery/night detection dashboard.
