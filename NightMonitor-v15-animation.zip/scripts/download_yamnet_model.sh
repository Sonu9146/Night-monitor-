#!/usr/bin/env bash
set -euo pipefail
mkdir -p app/src/main/assets
curl -L --fail --retry 3 \
  "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite" \
  -o app/src/main/assets/yamnet.tflite
printf 'Downloaded %s bytes to app/src/main/assets/yamnet.tflite\n' "$(wc -c < app/src/main/assets/yamnet.tflite)"
