$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path 'app/src/main/assets' | Out-Null
$url = 'https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite'
$out = 'app/src/main/assets/yamnet.tflite'
Invoke-WebRequest -Uri $url -OutFile $out
Write-Host "Downloaded $((Get-Item $out).Length) bytes to $out"
