package com.nightmonitor.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class MonitorService : Service() {

    companion object {
        const val ACTION_START = "com.nightmonitor.app.action.START"
        const val ACTION_STOP = "com.nightmonitor.app.action.STOP"
        const val EVENT_ACTION = "com.nightmonitor.app.EVENT"
        const val CHANNEL_ID = "night_monitor_channel"
        const val NOTIF_ID = 1
    }

    private var audioRecord: AudioRecord? = null
    private var recordThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var suppressUntil = 0L
    private var consecutiveHits = 0
    private var noiseFloor = 0.0
    private var lastLiveBroadcast = 0L
    private var lastInferenceAt = 0L
    private var aiPositiveWindows = 0
    private var lastTriggerAt = 0L
    private lateinit var prefs: SharedPreferences
    private var catClassifier: CatSoundClassifier? = null
    private var sessionDetections = 0
    private var sessionStartedAt = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("night_monitor_prefs", Context.MODE_PRIVATE)
        createChannel()
        catClassifier = CatSoundClassifier(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification("Listening for your cat\u2026"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        sessionStartedAt = System.currentTimeMillis()
        sessionDetections = 0
        prefs.edit().putLong("sessionStartedAt", sessionStartedAt).apply()
        startListeningLoop()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        recordThread?.interrupt()
        audioRecord?.let {
            try { it.stop() } catch (e: Exception) { }
            it.release()
        }
        audioRecord = null
        catClassifier?.close()
        catClassifier = null
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Night Monitor", NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Keeps listening for your cat while the screen is off"
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, MonitorService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Night Monitor")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun startListeningLoop() {
        if (running) return
        running = true
        recordThread = Thread {
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufSize = if (minBuf > 0) minBuf * 2 else 4096
            val buffer = ShortArray(bufSize / 2)
            var prevSample = 0.0
            val aiWindow = ShortArray(CatSoundClassifier.INPUT_SAMPLES)
            var aiWindowCount = 0
            var localRecord: AudioRecord? = null
            var lastScheduleState = false

            fun closeRecord() {
                localRecord?.let {
                    try { it.stop() } catch (_: Exception) { }
                    try { it.release() } catch (_: Exception) { }
                }
                localRecord = null
                audioRecord = null
                aiWindowCount = 0
                consecutiveHits = 0
                aiPositiveWindows = 0
                noiseFloor = 0.0
            }

            fun inSchedule(now: Calendar = Calendar.getInstance()): Boolean {
                if (!prefs.getBoolean("scheduleEnabled", false)) return true
                val start = prefs.getInt("scheduleStart", 22 * 60).coerceIn(0, 1439)
                val end = prefs.getInt("scheduleEnd", 7 * 60).coerceIn(0, 1439)
                val current = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                return if (start == end) true
                else if (start < end) current >= start && current < end
                else current >= start || current < end
            }

            fun scheduleLabel(): String {
                val start = prefs.getInt("scheduleStart", 22 * 60).coerceIn(0, 1439)
                val end = prefs.getInt("scheduleEnd", 7 * 60).coerceIn(0, 1439)
                fun fmt(m: Int): String {
                    val h = m / 60
                    val min = m % 60
                    val am = if (h < 12) "AM" else "PM"
                    val hh = when (val x = h % 12) { 0 -> 12; else -> x }
                    return String.format(Locale.getDefault(), "%d:%02d %s", hh, min, am)
                }
                return "${fmt(start)}–${fmt(end)}"
            }

            try {
                while (running) {
                    val scheduled = inSchedule()
                    if (!scheduled) {
                        if (lastScheduleState) {
                            closeRecord()
                            updateNotification("Night schedule paused • ${scheduleLabel()}")
                            broadcastStatus("Schedule paused • next window ${scheduleLabel()}", catClassifier?.isReady() == true)
                            lastScheduleState = false
                        } else {
                            updateNotification("Schedule sleeping • ${scheduleLabel()}")
                        }
                        Thread.sleep(15000L)
                        continue
                    }

                    if (!lastScheduleState) {
                        updateNotification(if (prefs.getBoolean("scheduleEnabled", false)) "Night schedule active • listening" else "Listening for your cat…")
                        broadcastStatus(if (prefs.getBoolean("scheduleEnabled", false)) "Listening • schedule active" else "Listening", catClassifier?.isReady() == true)
                        lastScheduleState = true
                    }

                    if (localRecord == null) {
                        localRecord = try {
                            AudioRecord(
                                MediaRecorder.AudioSource.MIC, sampleRate,
                                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize
                            )
                        } catch (_: SecurityException) { null }

                        val created = localRecord
                        if (created == null || created.state != AudioRecord.STATE_INITIALIZED) {
                            localRecord = null
                            broadcastStatus("Microphone unavailable • check permission", false)
                            Thread.sleep(3000L)
                            continue
                        }
                        audioRecord = created
                        try {
                            created.startRecording()
                        } catch (_: Exception) {
                            closeRecord()
                            Thread.sleep(1500L)
                            continue
                        }
                    }

                    val record = localRecord ?: continue
                    val readCount = try { record.read(buffer, 0, buffer.size) } catch (_: Exception) { -1 }
                    if (readCount <= 0) {
                        Thread.sleep(10L)
                        continue
                    }

                    if (prefs.getBoolean("scheduleEnabled", false) && !inSchedule()) {
                        closeRecord()
                        lastScheduleState = false
                        continue
                    }

                    val copyCount = minOf(readCount, aiWindow.size - aiWindowCount)
                    if (copyCount > 0) {
                        System.arraycopy(buffer, 0, aiWindow, aiWindowCount, copyCount)
                        aiWindowCount += copyCount
                    }

                    var sumSq = 0.0
                    var hpSumSq = 0.0
                    for (i in 0 until readCount) {
                        val sample = buffer[i].toDouble()
                        sumSq += sample * sample
                        val hp = sample - prevSample
                        prevSample = sample
                        hpSumSq += hp * hp
                    }
                    val rms = sqrt(sumSq / readCount)
                    val hpRms = sqrt(hpSumSq / readCount)
                    val level = (rms / 32768.0) * 100.0 * 6.0
                    val hpLevel = (hpRms / 32768.0) * 100.0 * 6.0
                    val pitchFocus = prefs.getBoolean("pitchFocus", true)
                    val ratio = if (level > 0.5) (hpLevel / level) else 0.0
                    val effectiveLevel = if (pitchFocus) level * (0.5 + ratio.coerceIn(0.0, 2.0)) else level

                    if (noiseFloor == 0.0) noiseFloor = effectiveLevel
                    else if (effectiveLevel < noiseFloor * 1.5) noiseFloor = noiseFloor * 0.98 + effectiveLevel * 0.02

                    val userThreshold = prefs.getInt("sensitivity", 22).toDouble()
                    val adaptiveThreshold = maxOf(userThreshold, noiseFloor * 2.0)
                    val now = System.currentTimeMillis()
                    val isCandidate = effectiveLevel > adaptiveThreshold
                    if (isCandidate) consecutiveHits++ else consecutiveHits = maxOf(0, consecutiveHits - 1)

                    val testMode = prefs.getBoolean("testMode", false)
                    val classifier = catClassifier
                    val windowReady = aiWindowCount >= CatSoundClassifier.INPUT_SAMPLES
                    val batterySaver = prefs.getBoolean("batterySaver", true)
                    val inferenceGap = when { testMode -> 900L; batterySaver -> 1200L; else -> 700L }
                    val shouldInfer = windowReady && (now - lastInferenceAt >= inferenceGap) &&
                        (testMode || (now > suppressUntil && consecutiveHits >= 3))

                    if (shouldInfer) {
                        consecutiveHits = 0
                        lastInferenceAt = now
                        val aiResult = if (classifier?.isReady() == true) classifier.classify(aiWindow, aiWindowCount) else null
                        aiWindowCount = 0
                        val aiThreshold = prefs.getInt("aiThreshold", 65) / 100f
                        val cooldownMs = prefs.getInt("cooldownSec", 15).coerceIn(5, 120) * 1000L

                        if (classifier?.isReady() == true && aiResult != null) {
                            broadcastLive(aiResult)
                            if (aiResult.catConfidence >= aiThreshold) aiPositiveWindows++ else aiPositiveWindows = 0
                            val confirmed = aiPositiveWindows >= 2
                            if (!testMode && confirmed) {
                                aiPositiveWindows = 0
                                if (now - lastTriggerAt >= cooldownMs) {
                                    lastTriggerAt = now
                                    handleTrigger(aiResult.catConfidence, aiResult.bestCatLabel)
                                } else {
                                    updateNotification("Cat sound confirmed • cooldown active")
                                    broadcastEvent("ignored", now, aiResult.catConfidence, aiResult.bestCatLabel, true)
                                }
                            } else if (!testMode && aiResult.catConfidence < aiThreshold) {
                                updateNotification("AI ignored ${aiResult.topLabel ?: "non-cat sound"} • ${(aiResult.catConfidence * 100).toInt()}% cat")
                                broadcastEvent("ignored", now, aiResult.catConfidence, aiResult.bestCatLabel, true)
                            }
                        } else if (!testMode) {
                            aiPositiveWindows = 0
                            if (now - lastTriggerAt >= cooldownMs) {
                                lastTriggerAt = now
                                handleTrigger(null, null)
                            }
                        } else {
                            broadcastStatus("AI model not installed — test mode is showing smart-filter activity", false)
                        }
                    } else if (now - lastLiveBroadcast > 1000L) {
                        lastLiveBroadcast = now
                        broadcastStatus(if (classifier?.isReady() == true) "Listening • AI ready" else "Listening • smart filter", classifier?.isReady() == true)
                    }
                }
            } finally {
                closeRecord()
            }
        }
        recordThread?.start()
    }

    private fun handleTrigger(aiConfidence: Float? = null, label: String? = null) {
        sessionDetections++
        prefs.edit().putInt("totalDetections", prefs.getInt("totalDetections", 0) + 1).putLong("lastDetectionAt", System.currentTimeMillis()).apply()
        val autoPlay = prefs.getBoolean("autoPlay", true)
        val clipFile = File(filesDir, "voice_clip.m4a")
        val when0 = Date()
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())

        if (autoPlay && clipFile.exists()) {
            try {
                val mp = MediaPlayer()
                mp.setDataSource(clipFile.absolutePath)
                mp.setOnPreparedListener { player ->
                    val durationMs = player.duration.toLong().coerceAtLeast(1000L)
                    suppressUntil = System.currentTimeMillis() + durationMs + 4000L
                    player.start()
                }
                mp.setOnCompletionListener { it.release() }
                mp.prepareAsync()
            } catch (e: Exception) {
                suppressUntil = System.currentTimeMillis() + 6000L
            }
            val suffix = aiConfidence?.let { " • AI ${(it * 100).toInt()}%" } ?: ""
            updateNotification("Played your clip at " + fmt.format(when0) + suffix)
            broadcastEvent("played", when0.time, aiConfidence, label, aiConfidence != null)
        } else {
            suppressUntil = System.currentTimeMillis() + 6000L
            val suffix = aiConfidence?.let { " • AI ${(it * 100).toInt()}%" } ?: ""
            updateNotification("Heard something at " + fmt.format(when0) + suffix)
            broadcastEvent("heard", when0.time, aiConfidence, label, aiConfidence != null)
        }
    }

    private fun broadcastEvent(type: String, timeMs: Long, confidence: Float? = null, label: String? = null, aiReady: Boolean = catClassifier?.isReady() == true) {
        val intent = Intent(EVENT_ACTION)
        intent.putExtra("type", type)
        intent.putExtra("time", timeMs)
        intent.putExtra("aiReady", aiReady)
        confidence?.let { intent.putExtra("confidence", it) }
        label?.let { intent.putExtra("label", it) }
        intent.setPackage(packageName)
        sendBroadcast(intent)
    }

    private fun broadcastLive(result: CatSoundClassifier.Result) {
        val intent = Intent(EVENT_ACTION)
        intent.putExtra("type", "live")
        intent.putExtra("time", System.currentTimeMillis())
        intent.putExtra("aiReady", true)
        intent.putExtra("confidence", result.catConfidence)
        intent.putExtra("label", result.bestCatLabel ?: result.topLabel ?: "Unknown")
        intent.putExtra("topLabel", result.topLabel ?: "Unknown")
        intent.putExtra("topConfidence", result.topConfidence)
        intent.setPackage(packageName)
        sendBroadcast(intent)
    }

    private fun broadcastStatus(text: String, aiReady: Boolean) {
        val intent = Intent(EVENT_ACTION)
        intent.putExtra("type", "status")
        intent.putExtra("time", System.currentTimeMillis())
        intent.putExtra("status", text)
        intent.putExtra("aiReady", aiReady)
        intent.setPackage(packageName)
        sendBroadcast(intent)
    }
}
