package com.nightmonitor.app

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Downloads and caches the YAMNet TFLite model in app-private storage. */
object ModelDownloader {
    const val MODEL_URL = "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite"
    const val FILE_NAME = "yamnet.tflite"

    fun modelFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun isModelPresent(context: Context): Boolean {
        val file = modelFile(context)
        return file.exists() && file.length() > 1_000_000L
    }

    fun download(context: Context, onDone: (Boolean, String) -> Unit) {
        Thread {
            val target = modelFile(context)
            val temp = File(context.filesDir, "$FILE_NAME.download")
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 60000
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                }
                connection.connect()
                if (connection.responseCode !in 200..299) {
                    throw Exception("HTTP ${connection.responseCode}")
                }

                BufferedInputStream(connection.inputStream).use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                        }
                    }
                }

                if (temp.length() <= 1_000_000L) throw Exception("Downloaded model is incomplete")
                if (target.exists()) target.delete()
                if (!temp.renameTo(target)) throw Exception("Could not save model")
                onDone(true, "AI model ready")
            } catch (e: Exception) {
                temp.delete()
                onDone(false, "AI model download failed: ${e.message ?: "network error"}")
            } finally {
                connection?.disconnect()
            }
        }.start()
    }
}
