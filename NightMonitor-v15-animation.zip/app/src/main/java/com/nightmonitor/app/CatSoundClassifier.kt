package com.nightmonitor.app

import android.content.Context
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/** Optional on-device YAMNet-compatible classifier. */
class CatSoundClassifier(private val context: Context) : AutoCloseable {
    companion object {
        private const val MODEL = "yamnet.tflite"
        const val SAMPLE_RATE = 16000
        // YAMNet's model input is 15600 PCM samples (~0.975 s) for its STFT framing.
        const val INPUT_SAMPLES = 15600
        private val CAT_INDICES = intArrayOf(76, 77, 78, 79, 80)
        private val CAT_LABELS = mapOf(76 to "Cat", 77 to "Purr", 78 to "Meow", 79 to "Hiss", 80 to "Caterwaul")
    }

    data class Result(
        val catConfidence: Float,
        val bestCatLabel: String?,
        val bestCatConfidence: Float,
        val topLabel: String?,
        val topConfidence: Float
    )

    private var interpreter: Interpreter? = null

    init {
        try {
            val file = ModelDownloader.modelFile(context)
            val bytes = if (file.exists() && file.length() > 1_000_000L) {
                file.readBytes()
            } else {
                context.assets.open(MODEL).use { it.readBytes() }
            }
            val model = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            model.put(bytes).rewind()
            interpreter = Interpreter(model)
        } catch (_: Exception) {
            interpreter = null
        }
    }

    fun isReady(): Boolean = interpreter != null

    fun classify(samples: ShortArray, count: Int): Result? {
        val t = interpreter ?: return null
        if (count <= 0) return null
        return try {
            val inputTensor = t.getInputTensor(0)
            val inputShape = inputTensor.shape()
            val inputElements = inputShape.fold(1) { a, b -> a * b }
            if (inputElements < INPUT_SAMPLES) return null

            val input = ByteBuffer.allocateDirect(inputTensor.numBytes()).order(ByteOrder.nativeOrder())
            when (inputTensor.dataType()) {
                DataType.FLOAT32 -> {
                    for (i in 0 until inputElements) {
                        val sample = if (i < count && i < INPUT_SAMPLES) samples[i] / 32768f else 0f
                        input.putFloat(sample)
                    }
                }
                DataType.INT8, DataType.UINT8 -> {
                    val q = inputTensor.quantizationParams()
                    val scale = if (q.scale == 0f) 1f else q.scale
                    for (i in 0 until inputElements) {
                        val sample = if (i < count && i < INPUT_SAMPLES) samples[i] / 32768f else 0f
                        val raw = (sample / scale + q.zeroPoint).roundToInt()
                        val minValue = if (inputTensor.dataType() == DataType.INT8) -128 else 0
                        val maxValue = if (inputTensor.dataType() == DataType.INT8) 127 else 255
                        input.put(raw.coerceIn(minValue, maxValue).toByte())
                    }
                }
                else -> return null
            }
            input.rewind()

            val outputTensor = t.getOutputTensor(0)
            val outputShape = outputTensor.shape()
            val classCount = outputShape.lastOrNull() ?: return null
            if (classCount < 81) return null
            val frameCount = if (outputShape.size <= 1) 1 else outputShape.dropLast(1).fold(1) { a, b -> a * b }
            val output = ByteBuffer.allocateDirect(outputTensor.numBytes()).order(ByteOrder.nativeOrder())
            t.run(input, output)
            output.rewind()

            val scores = FloatArray(classCount)
            for (frame in 0 until frameCount) {
                for (i in 0 until classCount) {
                    scores[i] += readScore(output, outputTensor.dataType(), outputTensor.quantizationParams().scale, outputTensor.quantizationParams().zeroPoint)
                }
            }
            if (frameCount > 1) for (i in scores.indices) scores[i] /= frameCount.toFloat()

            var topIndex = 0
            for (i in 1 until classCount) if (scores[i] > scores[topIndex]) topIndex = i
            var bestCat = 0f
            var bestLabel: String? = null
            for (index in CAT_INDICES) {
                if (index < classCount && scores[index] > bestCat) {
                    bestCat = scores[index].coerceIn(0f, 1f)
                    bestLabel = CAT_LABELS[index]
                }
            }
            Result(bestCat, bestLabel, bestCat, CAT_LABELS[topIndex] ?: "Class $topIndex", scores[topIndex].coerceIn(0f, 1f))
        } catch (_: Exception) {
            null
        }
    }

    private fun readScore(buffer: ByteBuffer, type: DataType, scale: Float, zeroPoint: Int): Float = when (type) {
        DataType.FLOAT32 -> buffer.float
        DataType.INT8 -> (buffer.get().toInt() - zeroPoint) * scale
        DataType.UINT8 -> ((buffer.get().toInt() and 0xFF) - zeroPoint) * scale
        else -> Float.NaN
    }

    override fun close() {
        interpreter?.close()
        interpreter = null
    }
}
