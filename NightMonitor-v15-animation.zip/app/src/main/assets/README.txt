Place a compatible YAMNet TFLite model here as:

    yamnet.tflite

The app will show "AI model ready" only when the model successfully loads.
