# NightMonitor v10 — AI model download fix

## Fixed
- Added an in-app **Download AI model** button.
- Added HTTPS model download + local cache in `filesDir/yamnet.tflite`.
- `CatSoundClassifier` now loads the cached model before falling back to assets.
- Added INTERNET permission.
- Fixed INT8 input quantization clamp to the correct `-128..127` range.
- Download uses a temporary file and only replaces the model after a complete download.

## Use
1. Build/install this project.
2. Open NightMonitor.
3. Tap **Download AI model**.
4. Wait for **AI model ready ✓**.
5. Start monitoring.

If the phone has no internet connection, the app will stay in smart-filter mode until the model download succeeds.
