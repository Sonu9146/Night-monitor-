# NightMonitor v11

- Added configurable response cooldown (5–120 seconds) to prevent repeated playback when a cat keeps vocalizing.
- Cooldown applies to AI-confirmed triggers and smart-filter fallback triggers.
- Added cooldown control to the main screen.
- Keeps the v10 AI model downloader and quantized-model fixes.
- AI still requires the downloaded YAMNet model; without it the app explicitly falls back to smart-filter mode.
