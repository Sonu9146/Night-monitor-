# NightMonitor v9 — build notes

This project is prepared for an Android Gradle build. Android apps are normally compiled and packaged by Gradle/Android Gradle Plugin.

## If using a phone-only environment
A working Android SDK + JDK + Gradle installation is required. Once available:

```sh
./gradlew :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Add the real model
Put the actual `yamnet.tflite` file at:

`app/src/main/assets/yamnet.tflite`

Then rebuild. The app reports **AI model ready** only if the model loads successfully.

## Important
This repository does not bundle a model downloaded from the internet. The download scripts are helpers; verify the model source and license before distributing it.
