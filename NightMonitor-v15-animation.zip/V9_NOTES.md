# NightMonitor v9

- Hardened TFLite inference to use tensor-sized ByteBuffers.
- Handles FLOAT32, INT8 and UINT8 input/output tensors.
- Avoids invalid Java array shapes for quantized tensors.
- Keeps Test Mode, live confidence, detection history and cooldown from v8.
- Keeps the AI model optional; no fake AI-ready state when `yamnet.tflite` is absent.
- Added build helper scripts and phone/build notes.
