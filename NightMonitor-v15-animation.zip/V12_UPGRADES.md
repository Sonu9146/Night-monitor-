# NightMonitor v12 — Night Schedule

- Added a configurable Night Schedule with start/end times.
- While monitoring is running, the service releases the microphone outside the scheduled window and resumes it inside the window.
- Handles overnight windows such as 10:00 PM → 7:00 AM.
- Added explicit microphone foreground-service startup using the AndroidX ServiceCompat API and microphone FGS type.
- Schedule does not silently start a microphone service in the background; the user starts monitoring from the visible app first. This follows Android's while-in-use microphone/foreground-service restrictions.
